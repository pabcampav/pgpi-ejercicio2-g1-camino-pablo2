# Práctica 2 PGPI: Filtro Antirrebotes (Debouncer en C)

Proyecto base para la práctica de Git avanzado en C (Linux).

## Compilación y Ejecución
```bash
make clean
make
./test_debouncer
